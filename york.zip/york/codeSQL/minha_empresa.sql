create database minha_empresa;
create table usuario(
	id_user int primary key auto_increment,
	usuario varchar(50) not null,
    telefone varchar(15),
    login varchar(15) not null unique,
    senha varchar(15) not null,
    perfil varchar(15) not null
);

insert into usuario(usuario, telefone, login, senha, perfil)
values('York Justo', '930751850', 'york', '1234', 'user'),
	  ('Administrador', '924574602', 'admin', '12345', 'admin');

select * from usuario;

create table cliente(
	id_cliente int primary key auto_increment,
    nome varchar(100) not null,
    endereco varchar(50) not null,
    telefone varchar(15),
    email varchar(50)
);

insert into cliente(nome, endereco, telefone, email)
values('Queiroz Santana', 'Bairro Social', '940662564', 'quey.ms@gmail.com'),
	  ('Quelson Jacinto', 'Bairro Sinai velho', '924607083', 'kelsonjacinto@gmail.com');

select * from cliente;

create table orde_de_service(
	id_os int primary key auto_increment,
    data_os timestamp default current_timestamp,
    tipo varchar(15) not null,
    situacao varchar(20) not null,
    equipamento varchar(20) not null,
    defeito varchar(40) not null,
    servico varchar(50) not null,
    tecnico varchar(30) not null,
    valor_a_pagar decimal(10,2) not null,
    id_cliente_f int not null,
    foreign key(id_cliente_f) references cliente(id_cliente)
);

insert into orde_de_service(tipo, situacao, equipamento, defeito, servico, tecnico, valor_a_pagar, id_cliente_f)
values('Orçamento', 'Na bancada', 'PC TOSHIBA', 'Vírus', 'Remover vírus', 'Baptista', 50.00, 1);

-- O código abaixo gera o relatório, ou seja, traz informações das duas tabelas
select Ordem.id_os,equipamento,defeito,servico,tecnico,valor_a_pagar,
Cliente.nome,telefone
from orde_de_service as Ordem
inner join cliente as Cliente
on (Ordem.id_cliente_f = Cliente.id_cliente);
